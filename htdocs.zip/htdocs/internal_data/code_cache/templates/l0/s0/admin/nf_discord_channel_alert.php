<?php
// FROM HASH: 633d61b022b8a5e7ac15aca4058bdd0d
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Alert users');
	$__finalCompiled .= '
';
	$__templater->pageParams['pageDescription'] = $__templater->preEscaped('You can use this form to send an alert to the users which match the criteria specified below.');
	$__templater->pageParams['pageDescriptionMeta'] = true;
	$__finalCompiled .= '
';
	$__templater->includeJs(array(
		'addon' => 'NF/Discord',
		'src' => 'nf/discord/websocket.js',
		'min' => '1',
	));
	$__finalCompiled .= '
';
	if ($__vars['sent']) {
		$__finalCompiled .= '
    ';
		if ($__vars['failed'] > 0) {
			$__finalCompiled .= '
        <div class="blockMessage blockMessage--warning blockMessage--iconic">
            ' . 'We were unable to send your alert to ' . $__templater->filter($__vars['failed'], array(array('number', array()),), true) . ' channels.' . '
        </div>
    ';
		}
		$__finalCompiled .= '
    ';
		if ($__vars['success'] > 0) {
			$__finalCompiled .= '
        <div class="blockMessage blockMessage--success blockMessage--iconic">
            ' . 'Your alert was sucessfully sent to ' . $__templater->filter($__vars['success'], array(array('number', array()),), true) . ' channels.' . '
        </div>
    ';
		}
		$__finalCompiled .= '
';
	}
	$__finalCompiled .= '

';
	$__compilerTemp1 = $__templater->mergeChoiceOptions(array(), $__vars['channels']);
	$__finalCompiled .= $__templater->form('
    <div class="block-container">
        <div class="block-body">
            ' . $__templater->formCheckBoxRow(array(
		'name' => 'channels',
		'listclass' => 'listColumns',
	), $__compilerTemp1, array(
		'label' => 'Channels',
		'explain' => 'Select the text channel(s) you wish to alert.',
	)) . '

            <hr class="formRowSep" />
            ' . $__templater->formCodeEditorRow(array(
		'name' => 'message',
		'mode' => 'html',
		'data-line-wrapping' => 'true',
		'class' => 'codeEditor--autoSize codeEditor--proportional',
	), array(
		'label' => 'Alert body',
		'explain' => 'You may also use {phrase:phrase_title} which will be replaced with the phrase text in the default language.',
	)) . '
        </div>

        ' . $__templater->formSubmitRow(array(
		'submit' => 'Send',
		'sticky' => 'true',
	), array(
	)) . '
    </div>
', array(
		'action' => $__templater->func('link', array('discord/channels/alert', ), false),
		'class' => 'block',
	));
	return $__finalCompiled;
}
);