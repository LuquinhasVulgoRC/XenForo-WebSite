<?php
// FROM HASH: 963e200433bbf3546766345533e6e3f8
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if (!$__vars['role']['id']) {
		$__finalCompiled .= '
	';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Create New Role');
		$__finalCompiled .= '
';
	} else {
		$__finalCompiled .= '
	';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Edit role' . $__vars['xf']['language']['label_separator'] . ' ' . $__templater->escape($__vars['role']['name']));
		$__finalCompiled .= '
';
	}
	$__finalCompiled .= '

';
	$__templater->includeCss('public:color_picker.less');
	$__finalCompiled .= '
';
	$__templater->includeJs(array(
		'src' => 'xf/color_picker.js',
		'min' => '1',
	));
	$__finalCompiled .= '

';
	if ($__vars['role']['id']) {
		$__templater->pageParams['pageAction'] = $__templater->preEscaped('
	' . $__templater->button('', array(
			'href' => $__templater->func('link', array('discord/roles/delete', $__vars['role'], ), false),
			'icon' => 'delete',
			'overlay' => 'true',
		), '', array(
		)) . '
');
	}
	$__finalCompiled .= '

' . $__templater->form('
	<div class="block-container">
		' . $__templater->formTextBoxRow(array(
		'name' => 'name',
		'value' => $__vars['role']['name'],
	), array(
		'label' => 'Role name',
	)) . '

		' . $__templater->formNumberBoxRow(array(
		'name' => 'position',
		'value' => $__vars['role']['position'],
	), array(
		'label' => 'Role position',
	)) . '

		<h2 class="block-tabHeader tabs hScroller" data-xf-init="tabs h-scroller" role="tablist">
			<span class="hScroller-scroll">
				<a class="tabs-tab is-active" role="tab" tabindex="0" aria-controls="general-permissions">' . 'General permissions' . '</a>
				<a class="tabs-tab" role="tab" tabindex="1" aria-controls="text-permissions">' . 'Text permissions' . '</a>
				<a class="tabs-tab" role="tab" tabindex="3" aria-controls="voice-permissions">' . 'Voice permissions' . '</a>
			</span>
		</h2>

		<ul class="tabPanes block-body">
			<li class="is-active" role="tabpanel" id="general-permissions">' . $__templater->includeTemplate('nf_discord_general_permissions', $__vars) . '</li>
			<li role="tabpanel" id="text-permissions">' . $__templater->includeTemplate('nf_discord_text_permissions', $__vars) . '</li>
			<li role="tabpanel" id="voice-permissions">' . $__templater->includeTemplate('nf_discord_voice_permissions', $__vars) . '</li>
		</ul>

		' . $__templater->formSubmitRow(array(
		'sticky' => 'true',
		'icon' => 'save',
	), array(
	)) . '
	</div>
', array(
		'action' => $__templater->func('link', array('discord/roles/save', $__vars['role'], ), false),
		'ajax' => 'true',
		'class' => 'block',
	));
	return $__finalCompiled;
}
);