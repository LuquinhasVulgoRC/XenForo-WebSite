<?php
// FROM HASH: 00e7a90b54383364633a98a8f45c459b
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '#testDiscord dt {
	line-height: 28px;
}

#testDiscord dd > span {
	float: left;
}

#testDiscord .explain {
	padding: 5px 0 0 30px;
}

.good {
	color: green;
	font-size: 24px;
}

.bad {
	color: red;
	font-size: 24px;
}

.unknown {
	color: orange;
	font-size: 24px;
}';
	return $__finalCompiled;
}
);