<?php
// FROM HASH: 23a51f3664397c5c382811edc118cd82
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Test Discord integration');
	$__finalCompiled .= '
';
	$__templater->pageParams['pageDescription'] = $__templater->preEscaped('Use this tool to diagnose connection issues between Discord and XenForo.');
	$__templater->pageParams['pageDescriptionMeta'] = true;
	$__finalCompiled .= '

';
	$__templater->includeCss('nf_discord_test_integration.less');
	$__finalCompiled .= '
';
	$__templater->includeJs(array(
		'prod' => 'nf/discord/websocket.js',
		'dev' => 'nf/discord/websocket.js',
		'addon' => 'NF/Discord',
	));
	$__finalCompiled .= '

';
	if ($__vars['tested']) {
		$__finalCompiled .= '
	';
		$__compilerTemp1 = '';
		if ($__vars['bot']['username']) {
			$__compilerTemp1 .= '
						' . $__templater->escape($__vars['bot']['username']) . '#' . $__templater->escape($__vars['bot']['discriminator']) . '
					';
		} else {
			$__compilerTemp1 .= '
						<div span style="font-weight: bold; color: red;">' . 'The connection attempt was unsuccessful. Please verify your Discord API details, and that your server has working DNS and can make outbound HTTPS connections.' . '</div>
					';
		}
		$__compilerTemp2 = '';
		if ($__vars['guild']) {
			$__compilerTemp2 .= '
						<div span style="font-weight: bold;">' . 'Our tests show that XenForo and your Discord server are playing nicely. You\'re all set!' . '</div>
					';
		} else {
			$__compilerTemp2 .= '
						<div span style="font-weight: bold; color: red;">' . 'The connection attempt was unsuccessful. Please verify your Discord API details and ensure the bot has been invited to your server.' . '</div>
					';
		}
		$__finalCompiled .= $__templater->form('
		<div class="block-container">
			<div class="block-body">
				' . $__templater->formRow('
					' . $__compilerTemp1 . '
				', array(
			'label' => 'Discord bot',
		)) . '

				' . $__templater->formRow('
					' . $__templater->escape($__vars['guild']['name']) . '
					' . $__compilerTemp2 . '
				', array(
			'label' => 'Discord server',
		)) . '

				' . $__templater->formRow('
					<div class="blockMessage blockMessage--' . ($__vars['checks']['canConnect'] ? 'success' : 'error') . ' blockMessage--small">
						' . 'We need to be able to connect to your Discord server before we can work our magic. Ensure your API details are all correct <a href="admin.php?connected-accounts/nfDiscord/edit" target="_blank">here</a>.' . '
					</div>
				', array(
			'label' => 'Connection status',
		)) . '

				' . $__templater->formRow('
					<div class="blockMessage blockMessage--' . ($__vars['checks']['botPresent'] ? 'success' : 'error') . ' blockMessage--small">
						' . 'To interact and post messages to your channel, a Discord bot must be present in your server. <br/><br/>

You\'ll need to obtain your Bot Authorization Token after bundling a bot with your Web API Application <a href="https://discord.com/developers/applications/me" target="_blank">here</a>. Enture your bot is not public and that \'Require OAuth2 Code Grant\' is not checked.<br/><br/>

Once you have your Bot Authorization Token, enter it in the <a href="admin.php?options/groups/nfDiscord/" target="_blank">Options area</a> and invite your new bot friend to your Discord server by using the tool below.' . '
					</div>
				', array(
			'label' => 'Bot present',
		)) . '

				' . $__templater->formRow('
					<div class="blockMessage blockMessage--' . ($__vars['checks']['widgetEnabled'] ? 'success' : 'error') . ' blockMessage--small">
						' . 'Before using the widgets supplied with this add-on, you\'ll need to ensure widget support is enabled within your Discord server settings. Enable widget support by checking the appropriate checkbox from the widget tab under Server Settings for your Discord server.' . '
					</div>
				', array(
			'label' => 'Widget enabled',
		)) . '
			</div>
		</div>
	', array(
			'action' => '#',
			'class' => 'block',
		)) . '

	' . $__templater->form('
		<div class="block-container">
			<div class="block-body">
				' . $__templater->formInfoRow('A bot must be present in your server for the integration to work. Use the button below to invite the bot in to your server.', array(
			'rowtype' => 'confirm',
		)) . '
			</div>

			' . $__templater->formSubmitRow(array(
			'submit' => 'Invite bot to server',
		), array(
			'rowtype' => 'simple',
		)) . '
		</div>
	', array(
			'action' => $__vars['link'],
			'method' => 'get',
			'class' => 'block',
		)) . '

	' . $__templater->form('
		<div class="block-container">
			<div class="block-body">
				' . $__templater->formInfoRow('
					' . 'In order for your XenForo to be able to relay messages via the Discord bot, you must first send a \'heart beat\' to Discord\'s servers. Use the button below to trigger that and you should be good to go.' . '
				', array(
			'rowtype' => 'confirm',
		)) . '
			</div>

			<dl class="formRow formSubmitRow formSubmitRow--simple">
				<dt></dt>
				<dd>
					<div class="formSubmitRow-main">
						<div class="formSubmitRow-bar"></div>
						<div class="formSubmitRow-controls">
							' . $__templater->button('
								' . 'Open WebSocket' . '
							', array(
			'class' => 'button--primary',
			'data-xf-click' => 'websocket',
			'data-token' => $__vars['provider']['options']['token'],
		), '', array(
		)) . '
						</div>
					</div>
				</dd>
			</dl>
		</div>
	', array(
			'action' => '#',
			'class' => 'block',
		)) . '
';
	} else {
		$__finalCompiled .= '
	' . $__templater->form('
		<div class="block-container">
			<div class="block-body">
				' . $__templater->formRow('
					' . $__templater->escape($__vars['provider']['options']['guild_id']) . '
				', array(
			'label' => 'Guild ID',
			'explain' => 'This is the Server ID of the Discord server that you will be integrating XenForo with. For more information on obtaining your Server ID, see <a href="https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-server-ID-" target="_blank">this guide</a>.',
		)) . '

				' . $__templater->formRow('
					' . $__templater->escape($__vars['provider']['options']['client_id']) . '
				', array(
			'label' => 'Client ID',
			'explain' => 'The Client ID can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
		)) . '

				' . $__templater->formRow('
					' . $__templater->escape($__vars['provider']['options']['client_secret']) . '
				', array(
			'label' => 'Client secret',
			'explain' => 'The Client Secret can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
		)) . '

				' . $__templater->formRow('
					' . $__templater->escape($__vars['provider']['options']['token']) . '
				', array(
			'label' => 'Bot token',
			'explain' => 'Your Discord application\'s bot token can be obtained after bundling a Bot User with your newly created Web API Application <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.
<br /><br />
It is recommended that your bot is not public and also ensure that \'Require OAuth2 Code Grant\' is not checked.
<br /><br />
Once you have completed these steps, please invite your new Bot to your Discord server by visiting <a href="admin.php?discord/invite-bot" target="_blank">this page</a>.',
		)) . '

				' . $__templater->formSubmitRow(array(
			'submit' => 'Run test',
		), array(
		)) . '
			</div>
		</div>
	', array(
			'action' => $__templater->func('link', array('tools/test-discord', '', array('test' => 1, ), ), false),
			'class' => 'block',
		)) . '
';
	}
	return $__finalCompiled;
}
);