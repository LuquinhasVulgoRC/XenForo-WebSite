<?php
// FROM HASH: 892767bff99377d2b16e89bfcb4d0c17
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_read_messages}',
		'name' => 'READ_MESSAGES',
		'hint' => '{xf:phrase nfd_permission_read_messages_hint}',
		'checked' => $__vars['permissions']['READ_MESSAGES'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_send_messages}',
		'name' => 'SEND_MESSAGES',
		'hint' => '{xf:phrase nfd_permission_send_messages_hint}',
		'checked' => $__vars['permissions']['SEND_MESSAGES'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_send_tts_messages}',
		'name' => 'SEND_TTS_MESSAGES',
		'hint' => '{xf:phrase nfd_permission_send_tts_messages_hint}',
		'checked' => $__vars['permissions']['SEND_TTS_MESSAGES'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_manage_messages}',
		'name' => 'MANAGE_MESSAGES',
		'hint' => '{xf:phrase nfd_permission_manage_messages_hint}',
		'checked' => $__vars['permissions']['MANAGE_MESSAGES'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_embed_links}',
		'name' => 'EMBED_LINKS',
		'hint' => '{xf:phrase nfd_permission_embed_links_hint}',
		'checked' => $__vars['permissions']['EMBED_LINKS'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_attach_files}',
		'name' => 'ATTACH_FILES',
		'hint' => '{xf:phrase nfd_permission_attach_files_hint}',
		'checked' => $__vars['permissions']['ATTACH_FILES'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_read_message_history}',
		'name' => 'READ_MESSAGE_HISTORY',
		'hint' => '{xf:phrase nfd_permission_read_message_history_hint}',
		'checked' => $__vars['permissions']['READ_MESSAGE_HISTORY'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nfd_permission_mention_everyone}',
		'name' => 'MENTION_EVERYONE',
		'hint' => '{xf:phrase nfd_permission_mention_everyone_hint}',
		'checked' => $__vars['permissions']['MENTION_EVERYONE'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nf_discord_use_external_emojis}',
		'name' => 'USE_EXTERNAL_EMOJIS',
		'hint' => '{xf:phrase nf_discord_use_external_emojis_hint}',
		'checked' => $__vars['permissions']['USE_EXTERNAL_EMOJIS'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
' . $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => '{xf:phrase nf_discord_add_reactions}',
		'name' => 'ADD_REACTIONS',
		'hint' => '{xf:phrase nf_discord_add_reactions_hint}',
		'checked' => $__vars['permissions']['USE_EXTERNAL_EMOJIS'],
		'_type' => 'option',
	)), array(
		'label' => '',
	)) . '
';
	return $__finalCompiled;
}
);