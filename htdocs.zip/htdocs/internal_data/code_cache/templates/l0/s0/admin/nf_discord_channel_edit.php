<?php
// FROM HASH: 5cd3f16d0ee67b007d2880c3a9f17253
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if (!$__vars['channel']['id']) {
		$__finalCompiled .= '
    ';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Create new channel');
		$__finalCompiled .= '
    ';
	} else {
		$__finalCompiled .= '
    ';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Edit channel' . $__vars['xf']['language']['label_separator'] . ' ' . $__templater->escape($__vars['channel']['name']));
		$__finalCompiled .= '
';
	}
	$__finalCompiled .= '

';
	if ($__vars['channel']['id']) {
		$__templater->pageParams['pageAction'] = $__templater->preEscaped('
    ' . $__templater->button('', array(
			'href' => $__templater->func('link', array('discord/channels/delete', $__vars['channel'], ), false),
			'icon' => 'delete',
			'overlay' => 'true',
		), '', array(
		)) . '
');
	}
	$__finalCompiled .= '

' . $__templater->form('
    <div class="block-container">
        ' . $__templater->formTextBoxRow(array(
		'name' => 'name',
		'value' => $__vars['channel']['name'],
	), array(
		'label' => 'Channel name',
	)) . '

        ' . $__templater->formTextBoxRow(array(
		'name' => 'topic',
		'value' => $__vars['channel']['topic'],
	), array(
		'label' => 'Channel topic',
		'explain' => 'A short description of the channel that is displayed next to the name on Discord. Only affects <b>text</b> channels.',
	)) . '

        ' . $__templater->formSubmitRow(array(
		'sticky' => 'true',
		'icon' => 'save',
	), array(
	)) . '
    </div>
', array(
		'action' => $__templater->func('link', array('discord/channels/save', $__vars['channel'], ), false),
		'ajax' => 'true',
		'class' => 'block',
	));
	return $__finalCompiled;
}
);