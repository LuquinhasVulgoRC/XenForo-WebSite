<?php
// FROM HASH: 36d5cd2d22859969ebf0ef9f47806f8f
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Channels');
	$__finalCompiled .= '

';
	$__templater->pageParams['pageAction'] = $__templater->preEscaped('
    ' . $__templater->button('
        ' . 'Alert...' . '
    ', array(
		'href' => $__templater->func('link', array('discord/channels/alert', ), false),
	), '', array(
	)) . '
');
	$__finalCompiled .= '

';
	if ($__vars['channels']) {
		$__finalCompiled .= '
    <div class="block">
        <div class="block-outer">
            ' . $__templater->callMacro('filter_macros', 'quick_filter', array(
			'key' => 'channels',
			'class' => 'block-outer-opposite',
		), $__vars) . '
        </div>
        <div class="block-container">
            <div class="block-body">
                ';
		$__compilerTemp1 = '';
		if ($__templater->isTraversable($__vars['channels'])) {
			foreach ($__vars['channels'] AS $__vars['channel']) {
				$__compilerTemp1 .= '
                        ' . $__templater->dataRow(array(
					'label' => $__templater->escape($__vars['channel']['name']),
					'href' => $__templater->func('link', array('discord/channels/edit', $__vars['channel'], ), false),
					'hint' => $__templater->escape($__vars['channel']['topic']),
					'delete' => $__templater->func('link', array('discord/channels/delete', $__vars['channel'], ), false),
				), array()) . '
                    ';
			}
		}
		$__finalCompiled .= $__templater->dataList('
                    ' . $__compilerTemp1 . '
                ', array(
		)) . '
            </div>
            <div class="block-footer">
                <span class="block-footer-counter">' . $__templater->func('display_totals', array($__vars['channels'], ), true) . '</span>
            </div>
        </div>
    </div>
';
	} else {
		$__finalCompiled .= '
    <div class="blockMessage">' . 'No channels found. Perhaps the bot lacks the "Manage Channels" permission.' . '</div>
';
	}
	return $__finalCompiled;
}
);