<?php
// FROM HASH: 9da555b6635208f4a7a2cf3326bfdb60
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if ($__vars['invalid']) {
		$__finalCompiled .= '
	' . $__templater->formRow('
		' . 'Discord must be configured before this option can be configured.' . '
	', array(
			'label' => $__templater->escape($__vars['option']['title']),
		)) . '
	';
	} else {
		$__finalCompiled .= '
	';
		if (!$__templater->test($__vars['roles'], 'empty', array())) {
			$__finalCompiled .= '
			';
			$__compilerTemp1 = array(array(
				'value' => '0',
				'label' => 'No role selected',
				'_type' => 'option',
			));
			if ($__templater->isTraversable($__vars['roles'])) {
				foreach ($__vars['roles'] AS $__vars['role']) {
					$__compilerTemp1[] = array(
						'value' => $__vars['role']['id'],
						'selected' => ($__vars['option']['option_value'] == $__vars['role']['id']),
						'label' => $__templater->escape($__vars['role']['name']),
						'_type' => 'option',
					);
				}
			}
			$__finalCompiled .= $__templater->formSelectRow(array(
				'name' => $__vars['inputName'],
				'value' => $__vars['option']['option_value'],
			), $__compilerTemp1, array(
				'label' => $__templater->escape($__vars['option']['title']),
				'hint' => $__templater->escape($__vars['hintHtml']),
				'explain' => $__templater->escape($__vars['explainHtml']),
				'html' => $__templater->escape($__vars['listedHtml']),
			)) . '
	';
		}
		$__finalCompiled .= '

';
	}
	return $__finalCompiled;
}
);