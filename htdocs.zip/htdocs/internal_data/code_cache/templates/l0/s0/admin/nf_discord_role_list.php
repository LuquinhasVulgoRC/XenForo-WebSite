<?php
// FROM HASH: 9d0b698ee95b006ac4651b510109a5d7
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Roles');
	$__finalCompiled .= '

';
	if ($__vars['roles']) {
		$__finalCompiled .= '
    <div class="block">
        <div class="block-outer">
            ' . $__templater->callMacro('filter_macros', 'quick_filter', array(
			'key' => 'roles',
			'class' => 'block-outer-opposite',
		), $__vars) . '
        </div>
        <div class="block-container">
            <div class="block-body">
                ';
		$__compilerTemp1 = '';
		if ($__templater->isTraversable($__vars['roles'])) {
			foreach ($__vars['roles'] AS $__vars['role']) {
				$__compilerTemp1 .= '
                        ' . $__templater->dataRow(array(
					'label' => $__templater->escape($__vars['role']['name']),
					'hint' => ($__vars['role']['admin'] ? 'Admin' : ''),
					'href' => $__templater->func('link', array('discord/roles/edit', $__vars['role'], ), false),
					'delete' => $__templater->func('link', array('discord/roles/delete', $__vars['role'], ), false),
				), array()) . '
                    ';
			}
		}
		$__finalCompiled .= $__templater->dataList('
                    ' . $__compilerTemp1 . '
                ', array(
		)) . '
            </div>
            <div class="block-footer">
                <span class="block-footer-counter">' . $__templater->func('display_totals', array($__vars['roles'], ), true) . '</span>
            </div>
        </div>
    </div>
    ';
	} else {
		$__finalCompiled .= '
    <div class="blockMessage">' . 'No channels found. Perhaps the bot lacks the "Manage Roles" permission.' . '</div>
';
	}
	return $__finalCompiled;
}
);