<?php
// FROM HASH: 9e102e6822c5551057f65e484aa95a6d
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if ($__vars['usergroup']['user_group_id']) {
		$__finalCompiled .= '
	';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Edit user group' . $__vars['xf']['language']['label_separator'] . ' ' . $__templater->escape($__vars['usergroup']['title']));
		$__finalCompiled .= '
	';
	} else {
		$__finalCompiled .= '
	';
		$__templater->pageParams['pageTitle'] = $__templater->preEscaped('create_user_group');
		$__finalCompiled .= '
';
	}
	$__finalCompiled .= '

';
	$__templater->breadcrumb($__templater->preEscaped('User groups'), $__templater->func('link', array('discord/groups/user', ), false), array(
	));
	$__finalCompiled .= '

';
	$__compilerTemp1 = array();
	if ($__templater->isTraversable($__vars['roles'])) {
		foreach ($__vars['roles'] AS $__vars['role']) {
			$__compilerTemp1[] = array(
				'value' => $__vars['role']['id'],
				'id' => 'role-' . $__vars['role']['id'],
				'selected' => $__templater->func('in_array', array($__vars['role']['id'], $__vars['selRoleIds'], ), false),
				'label' => $__templater->escape($__vars['role']['name']),
				'_type' => 'option',
			);
		}
	}
	$__finalCompiled .= $__templater->form('
	<div class="block-container">
		<div class="block-body">
			' . $__templater->formCheckBoxRow(array(
		'name' => 'roles',
		'listclass' => 'listColumns',
	), $__compilerTemp1, array(
		'label' => 'Associated Discord Roles',
		'hint' => 'Do not assign the same role that the bot is in to a user.',
	)) . '

			' . $__templater->formSubmitRow(array(
		'icon' => 'save',
	), array(
	)) . '
		</div>
	</div>
', array(
		'action' => $__templater->func('link', array('discord/groups/user/save', $__vars['usergroup'], ), false),
		'data-ajax' => 'true',
		'class' => 'block',
	));
	return $__finalCompiled;
}
);