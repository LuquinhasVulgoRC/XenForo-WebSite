<?php
// FROM HASH: 649c04020bc28d8328f08551690aec5e
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="blockMessage">' . $__templater->filter($__vars['message'], array(array('raw', array()),), true) . '</div>';
	return $__finalCompiled;
}
);