<?php
// FROM HASH: b232cb4fa47e86f419970f63b0cf8f2f
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => 'Read messages',
		'name' => 'READ_MESSAGES',
		'hint' => 'Members with this permission can see messages in chat channels.',
		'checked' => $__vars['permissions']['READ_MESSAGES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Send messages',
		'name' => 'SEND_MESSAGES',
		'hint' => 'Members with this permission can post messages in chat channels.',
		'checked' => $__vars['permissions']['SEND_MESSAGES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Send tts messages',
		'name' => 'SEND_TTS_MESSAGES',
		'hint' => 'Members with this permission can send text-to-speech messages by starting a message with <b>/tts</b>. These messages can be heard by everyone focused on the channel.',
		'checked' => $__vars['permissions']['SEND_TTS_MESSAGES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage messages',
		'name' => 'MANAGE_MESSAGES',
		'hint' => 'Members with this permission can delete messages by other members or pin any message.',
		'checked' => $__vars['permissions']['MANAGE_MESSAGES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Embed links',
		'name' => 'EMBED_LINKS',
		'hint' => 'Members with this permission can have their links show a preview below the link.',
		'checked' => $__vars['permissions']['EMBED_LINKS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Attach files',
		'name' => 'ATTACH_FILES',
		'hint' => 'Members with this permission can upload files to the focused channel.',
		'checked' => $__vars['permissions']['ATTACH_FILES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Read message history',
		'name' => 'READ_MESSAGE_HISTORY',
		'hint' => 'Members with this permission can view the message history of the focused channel.',
		'checked' => $__vars['permissions']['READ_MESSAGE_HISTORY'],
		'_type' => 'option',
	),
	array(
		'label' => 'Mention everyone',
		'name' => 'MENTION_EVERYONE',
		'hint' => 'Members with this permission can trigger push notifications for all members of this channel by starting a message with <b>@everyone</b> or <b>@here</b>.',
		'checked' => $__vars['permissions']['MENTION_EVERYONE'],
		'_type' => 'option',
	),
	array(
		'label' => 'Use external emojis',
		'name' => 'USE_EXTERNAL_EMOJIS',
		'hint' => 'Members with this permission can use emojis from other servers in this server.',
		'checked' => $__vars['permissions']['USE_EXTERNAL_EMOJIS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Add reactions',
		'name' => 'ADD_REACTIONS',
		'hint' => 'Members with this permission can add new reactions new a message. Members can still react using reactions already added to messages without this permission.',
		'checked' => $__vars['permissions']['USE_EXTERNAL_EMOJIS'],
		'_type' => 'option',
	)), array(
		'label' => '',
	));
	return $__finalCompiled;
}
);