<?php
// FROM HASH: ed4a115790a163414821b597b36611cb
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('option_template_automatedEmailHandler', $__vars);
	return $__finalCompiled;
}
);