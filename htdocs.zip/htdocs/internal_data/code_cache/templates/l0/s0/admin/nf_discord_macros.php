<?php
// FROM HASH: 1e7931d64a3c65120de02d2b676b4867
return array(
'macros' => array('channel' => array(
'arguments' => function($__templater, array $__vars) { return array(
		'node' => '!',
		'channelList' => '!',
		'includeReplies' => false,
		'extra' => '',
	); },
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '
	';
	$__compilerTemp1 = array();
	if ($__templater->isTraversable($__vars['channelList'])) {
		foreach ($__vars['channelList'] AS $__vars['channel']) {
			$__compilerTemp1[] = array(
				'value' => $__vars['channel']['id'],
				'label' => $__templater->escape($__vars['channel']['name']),
				'_type' => 'option',
			);
		}
	}
	$__compilerTemp2 = '';
	if ($__vars['includeReplies']) {
		$__compilerTemp2 .= '
					' . $__templater->formCheckBox(array(
			'standalone' => 'true',
		), array(array(
			'name' => 'nf_discord_include_replies',
			'selected' => $__vars['node']['nf_discord_include_replies'],
			'label' => 'Include replies made to threads',
			'_type' => 'option',
		))) . '
				';
	}
	$__finalCompiled .= $__templater->formCheckBoxRow(array(
	), array(array(
		'name' => 'nf_discord',
		'selected' => $__vars['node']['nf_discord_channel_id'],
		'label' => 'Enable posting to Discord',
		'_dependent' => array($__templater->formSelect(array(
		'name' => 'nf_discord_channel_id',
		'value' => $__vars['node']['nf_discord_channel_id'],
	), $__compilerTemp1), '
				' . $__compilerTemp2 . '

				' . $__templater->filter($__vars['extra'], array(array('raw', array()),), true) . '
			'),
		'_type' => 'option',
	)), array(
	)) . '
';
	return $__finalCompiled;
}
)),
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';

	return $__finalCompiled;
}
);