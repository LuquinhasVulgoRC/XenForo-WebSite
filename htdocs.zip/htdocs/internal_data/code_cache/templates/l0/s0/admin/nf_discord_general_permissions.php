<?php
// FROM HASH: 1aa6f99dd41148aeb83482bc38ff1277
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => 'Administrator',
		'name' => 'ADMINISTRATOR',
		'hint' => 'Members with this permission have every permission and also bypass channel specific permissions. This is a dangerous permission to grant.',
		'checked' => $__vars['permissions']['ADMINISTRATOR'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage server',
		'name' => 'MANAGE_GUILD',
		'hint' => 'Members with this permission can change the server\'s name or voice region.',
		'checked' => $__vars['permissions']['MANAGE_GUILD'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage roles',
		'name' => 'MANAGE_ROLES',
		'hint' => 'Members with this permission can create new roles and edit/delete roles lower than this one.',
		'checked' => $__vars['permissions']['MANAGE_ROLES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage channels',
		'name' => 'MANAGE_CHANNELS',
		'hint' => 'Members with this permission can create new channels and edit or delete existing ones.',
		'checked' => $__vars['permissions']['MANAGE_CHANNELS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Kick members',
		'name' => 'KICK_MEMBERS',
		'hint' => 'Members with this permission can kick other members from the server.',
		'checked' => $__vars['permissions']['KICK_MEMBERS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Ban members',
		'name' => 'BAN_MEMBERS',
		'hint' => 'Members with this permission can ban other members from the server.',
		'checked' => $__vars['permissions']['BAN_MEMBERS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Create instant invite',
		'name' => 'CREATE_INSTANT_INVITE',
		'hint' => 'Members with this permission can create instant invites for new users to join the server with.',
		'checked' => $__vars['permissions']['CREATE_INSTANT_INVITE'],
		'_type' => 'option',
	),
	array(
		'label' => 'Change nickname',
		'name' => 'CHANGE_NICKNAME',
		'hint' => 'Members with this permission can change their own nickname.',
		'checked' => $__vars['permissions']['CHANGE_NICKNAME'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage nicknames',
		'name' => 'MANAGE_NICKNAMES',
		'hint' => 'Members with this permission can change nicknames of other members.',
		'checked' => $__vars['permissions']['MANAGE_NICKNAMES'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage emojis',
		'name' => 'MANAGE_EMOJIS',
		'hint' => 'Members with this permission can manage server-wide emojis.',
		'checked' => $__vars['permissions']['MANAGE_EMOJIS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Manage webhooks',
		'name' => 'MANAGE_WEBHOOKS',
		'hint' => 'Members with this permission can manage webhooks. <b>This permission requires the owner account to use two-factor authentication when used on a guild that has server-wide 2FA enabled.</b>',
		'checked' => $__vars['permissions']['MANAGE_WEBHOOKS'],
		'_type' => 'option',
	)), array(
		'label' => '',
	));
	return $__finalCompiled;
}
);