<?php
// FROM HASH: babddf30cc3cd02392ea3e4c822ab9ad
return array(
'macros' => array('changerone' => array(
'arguments' => function($__templater, array $__vars) { return array(
		'node' => '!',
		'name' => 'mb',
	); },
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '
<hr class="formRowSep" />
<dl class="formRow formRow--input">
	<dt>
		<div class="formRow-labelWrapper">
		<label class="formRow-label">' . 'Image Node Icon' . '</label></div>
	</dt>
	<dd>
		<div class="' . $__templater->escape($__vars['name']) . '">
			' . $__templater->formTextBox(array(
		'name' => $__vars['name'] . '[filtersetting]',
		'value' => $__vars['node']['new_icon'][$__vars['name']]['filtersetting'],
	)) . '
			<div class="formRow-explain">' . 'Simply put full link to the image. Example: <u>https://vertiforo.stylesfactory.pl/images/icons/nw.png</u>' . '</div>
			';
	if ($__vars['node']['new_icon']['mb']['filtersetting']) {
		$__finalCompiled .= '<br /><img src="' . $__templater->escape($__vars['node']['new_icon']['mb']['filtersetting']) . '">';
	}
	$__finalCompiled .= '
		</div>
	</dd>
</dl>

<dl class="formRow formRow--input">
	<dt>
		<div class="formRow-labelWrapper">
		<label class="formRow-label">' . 'Font Awesome Node Icon' . '</label></div>
	</dt>
	<dd>
		<div class="' . $__templater->escape($__vars['name']) . '">
			' . $__templater->formTextBox(array(
		'name' => 'node[font_icon]',
		'value' => $__vars['node']['font_icon'],
	)) . '
			<div class="formRow-explain">' . 'Get code from <a href="https://fontawesome.com/icons">Font Awesome</a> site. It should look like this: &lt;i class="fas fa-volume-down">&lt;/i>' . '</div>
		</div>
	</dd>	
</dl>

<dl class="formRow formRow--input">
	<dt>
		<div class="formRow-labelWrapper">
		<label class="formRow-label">' . 'SVG sprite' . '</label></div>
	</dt>
	<dd>
		<div class="' . $__templater->escape($__vars['name']) . '" style="padding-bottom:10px;">
			' . $__templater->formTextBox(array(
		'name' => 'node[svg_bg]',
		'value' => $__vars['node']['svg_bg'],
	)) . '
			<div class="formRow-explain">' . 'Set background position for sprite. Only .svg will work! ' . '</div>
		</div>		
	</dd>	
</dl>
';
	return $__finalCompiled;
}
)),
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '
  
' . '

';
	return $__finalCompiled;
}
);