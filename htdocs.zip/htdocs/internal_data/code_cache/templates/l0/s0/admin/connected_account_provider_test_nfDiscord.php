<?php
// FROM HASH: ae21299934be10a0bc5d680f4657aefe
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if (!$__vars['providerData']) {
		$__finalCompiled .= '
    ' . $__templater->formInfoRow('
        ' . 'This will test the ' . $__templater->escape($__vars['provider']['title']) . ' connected account provider. You must have a ' . $__templater->escape($__vars['provider']['title']) . ' account to perform this test.' . '
    ', array(
		)) . '

    ' . $__templater->formRow($__templater->escape($__vars['provider']['options']['client_id']), array(
			'label' => 'Client ID',
		)) . '
';
	} else {
		$__finalCompiled .= '
    ' . $__templater->formInfoRow('<strong>' . 'Test passed!' . '</strong>', array(
			'rowtype' => 'confirm',
		)) . '

    	' . $__templater->callMacro('connected_account_provider_test_macros', 'display_name', array(
			'name' => $__vars['providerData']['username'] . '#' . $__vars['providerData']['discriminator'],
		), $__vars) . '
		' . $__templater->callMacro('connected_account_provider_test_macros', 'picture', array(
			'url' => $__vars['providerData']['avatar_url'],
		), $__vars) . '
	' . $__templater->formRow(($__templater->escape($__vars['providerData']['email']) ?: 'N/A'), array(
			'label' => 'Email',
		)) . '
';
	}
	return $__finalCompiled;
}
);