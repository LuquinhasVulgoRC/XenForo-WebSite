<?php
// FROM HASH: 8e305cae429d8329236dd8ac398adb87
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->formTextBoxRow(array(
		'name' => 'options[guild_id]',
		'value' => $__vars['options']['guild_id'],
	), array(
		'label' => 'Guild ID',
		'hint' => 'Required',
		'explain' => 'This is the Server ID of the Discord server that you will be integrating XenForo with. For more information on obtaining your Server ID, see <a href="https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-server-ID-" target="_blank">this guide</a>.',
	)) . '

' . $__templater->formTextBoxRow(array(
		'name' => 'options[client_id]',
		'value' => $__vars['options']['client_id'],
	), array(
		'label' => 'Client ID',
		'hint' => 'Required',
		'explain' => 'The Client ID can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
	)) . '

' . $__templater->formTextBoxRow(array(
		'name' => 'options[client_secret]',
		'value' => $__vars['options']['client_secret'],
	), array(
		'label' => 'Client secret',
		'hint' => 'Required',
		'explain' => 'The Client Secret can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
	)) . '

' . $__templater->formTextBoxRow(array(
		'name' => 'options[token]',
		'value' => $__vars['options']['token'],
	), array(
		'label' => 'Bot token',
		'hint' => 'Required',
		'explain' => 'Your Discord application\'s bot token can be obtained after bundling a Bot User with your newly created Web API Application <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.
<br /><br />
It is recommended that your bot is not public and also ensure that \'Require OAuth2 Code Grant\' is not checked.
<br /><br />
Once you have completed these steps, please invite your new Bot to your Discord server by visiting <a href="admin.php?discord/invite-bot" target="_blank">this page</a>.',
	));
	return $__finalCompiled;
}
);