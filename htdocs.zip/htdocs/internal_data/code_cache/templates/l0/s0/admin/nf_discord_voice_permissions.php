<?php
// FROM HASH: 30f7285cec0f0902170cdd67a1801449
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->formCheckBoxRow(array(
	), array(array(
		'label' => 'Connect',
		'name' => 'CONNECT',
		'hint' => 'Members with this permission can connect to voice channels.',
		'checked' => $__vars['permissions']['CONNECT'],
		'_type' => 'option',
	),
	array(
		'label' => 'Speak',
		'name' => 'SPEAK',
		'hint' => 'Members with this permission can speak in voice channels.',
		'checked' => $__vars['permissions']['SPEAK'],
		'_type' => 'option',
	),
	array(
		'label' => 'Mute members',
		'name' => 'MUTE_MEMBERS',
		'hint' => 'Members with this permission can mute an other member\'s microphone.',
		'checked' => $__vars['permissions']['MUTE_MEMBERS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Deafen members',
		'name' => 'DEAFEN_MEMBERS',
		'hint' => 'Members with this permission can deafen other members.',
		'checked' => $__vars['permissions']['DEAFEN_MEMBERS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Move members',
		'name' => 'MOVE_MEMBERS',
		'hint' => 'Members with this permission can drag other members out of this channel. They can only move members between channels both they and the member they are moving have access.',
		'checked' => $__vars['permissions']['MOVE_MEMBERS'],
		'_type' => 'option',
	),
	array(
		'label' => 'Use voice activity',
		'name' => 'USE_VAD',
		'hint' => 'Members must use Push-to-talk in this channel if this permission is disallowed.',
		'checked' => $__vars['permissions']['USE_VAD'],
		'_type' => 'option',
	)), array(
		'label' => '',
	));
	return $__finalCompiled;
}
);