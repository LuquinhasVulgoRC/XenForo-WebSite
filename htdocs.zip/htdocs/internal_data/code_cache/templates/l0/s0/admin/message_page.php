<?php
// FROM HASH: 69436f0593c21adcf080b5caf552be15
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="blockMessage">' . $__templater->escape($__vars['message']) . '</div>';
	return $__finalCompiled;
}
);