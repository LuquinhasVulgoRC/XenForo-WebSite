<?php
// FROM HASH: 8e2999bb01a40324e294d54dfe0143e8
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Discord');
	$__finalCompiled .= '

' . $__templater->callMacro('section_nav_macros', 'section_nav', array(
		'section' => 'nfDiscord',
	), $__vars);
	return $__finalCompiled;
}
);