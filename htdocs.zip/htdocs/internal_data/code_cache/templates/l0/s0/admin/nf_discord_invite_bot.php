<?php
// FROM HASH: 11b148b7e0ed617d0762e9fc33fdc347
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__templater->pageParams['pageTitle'] = $__templater->preEscaped('Invite bot');
	$__finalCompiled .= '

<div class="block">
	<div class="block-container">
		<div class="block-body">
			' . $__templater->formInfoRow('
				' . 'A bot must be present in your server for the integration to work. Use the button below to invite the bot in to your server.' . '
				<div>
					' . $__templater->button('Invite bot to server', array(
		'href' => $__vars['link'],
		'icon' => 'confirm',
	), '', array(
	)) . '
				</div>
			', array(
		'rowtype' => 'confirm',
	)) . '
		</div>
	</div>
</div>';
	return $__finalCompiled;
}
);