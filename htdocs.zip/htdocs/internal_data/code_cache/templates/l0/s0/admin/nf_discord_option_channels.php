<?php
// FROM HASH: e44859940e7b6c830e62139f68af8cce
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	if ($__vars['invalid']) {
		$__finalCompiled .= '
	' . $__templater->formRow('
		' . 'Discord must be configured before this option can be configured.' . '
	', array(
			'label' => $__templater->escape($__vars['option']['title']),
		)) . '
';
	} else {
		$__finalCompiled .= '
	';
		if (!$__templater->test($__vars['channels'], 'empty', array())) {
			$__finalCompiled .= '
			';
			$__compilerTemp1 = array(array(
				'value' => '0',
				'label' => 'No channel selected',
				'_type' => 'option',
			));
			if ($__templater->isTraversable($__vars['channels'])) {
				foreach ($__vars['channels'] AS $__vars['channel']) {
					$__compilerTemp1[] = array(
						'value' => $__vars['channel']['id'],
						'selected' => ($__vars['option']['option_value'] == $__vars['channel']['id']),
						'label' => $__templater->escape($__vars['channel']['name']),
						'_type' => 'option',
					);
				}
			}
			$__finalCompiled .= $__templater->formSelectRow(array(
				'name' => $__vars['inputName'],
				'value' => $__vars['option']['option_value'],
			), $__compilerTemp1, array(
				'label' => $__templater->escape($__vars['option']['title']),
				'hint' => $__templater->escape($__vars['hintHtml']),
				'explain' => $__templater->escape($__vars['explainHtml']),
				'html' => $__templater->escape($__vars['listedHtml']),
			)) . '
	';
		}
		$__finalCompiled .= '

';
	}
	return $__finalCompiled;
}
);