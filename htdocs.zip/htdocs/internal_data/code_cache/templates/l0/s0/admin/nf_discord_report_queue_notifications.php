<?php
// FROM HASH: 7f7dc787d2dc0e8220694ebcb3d77c74
return array(
'code' => function($__templater, array $__vars, $__extensions = null)
{
	$__finalCompiled = '';
	$__vars['extra'] = $__templater->preEscaped('
	' . $__templater->formCheckBoxRow(array(
	), array(array(
		'name' => 'nf_discord_new_reports',
		'label' => 'Notify on new reports',
		'checked' => $__vars['reportQueue']['nf_discord_new_reports'],
		'_type' => 'option',
	)), array(
	)) . '
	' . $__templater->formCheckBoxRow(array(
	), array(array(
		'name' => 'nf_discord_reopened_reports',
		'label' => 'Notify on reopened reports',
		'checked' => $__vars['reportQueue']['nf_discord_reopened_reports'],
		'_type' => 'option',
	)), array(
	)) . '

	<div class="block-container">
		<div class="block-body">

			<h3 class="block-formSectionHeader">' . 'Send a Discord message when too many reports are open' . $__vars['xf']['language']['label_separator'] . '</h3>
			<dl class="formRow formRow--input">
				<dt>' . 'Phrase:' . '</dt>
				<dd><i>nfDiscord_notice.report_too_many_open</i><br/>' . '{queueName} has more than {openThreshold} open reports; it has {openCount} open reports' . ' </dd>
			</dl>

			<dl class="formRow formRow--input">
				<dt>' . 'Open Reports' . $__vars['xf']['language']['label_separator'] . '</dt>
				<dd>' . $__templater->formNumberBox(array(
		'name' => 'nf_discord_open_count',
		'value' => $__vars['reportQueue']['nf_discord_open_count'],
		'min' => '0',
	)) . '</dd>
			</dl>

			<dl class="formRow formRow--input">
				<dt>' . 'Time to wait before rechecking' . $__vars['xf']['language']['label_separator'] . '</dt>
				<dd><div class="inputGroup">
					' . $__templater->formNumberBox(array(
		'name' => 'nf_discord_open_threshold',
		'value' => $__vars['reportQueue']['nf_discord_open_threshold'],
		'min' => '0',
	)) . '
					<span class="inputGroup-text">' . 'minutes' . '</span>
					</div></dd>
			</dl>
		</div>

		<div class="block-body">

			<h3 class="block-formSectionHeader">' . 'Send a Discord message when there are old open reports' . $__vars['xf']['language']['label_separator'] . '</h3>
			<dl class="formRow formRow--input">
				<dt>' . 'Phrase:' . '</dt>
				<dd><i>nfDiscord_notice.report_old_open_reports</i><br/>' . '{queueName} has {openCount} open reports which are older than {time} hours' . ' </dd>
			</dl>

			<dl class="formRow formRow--input">
				<dt>' . 'Report open reports after' . $__vars['xf']['language']['label_separator'] . '</dt>
				<dd><div class="inputGroup">
					' . $__templater->formNumberBox(array(
		'name' => 'nf_discord_old_report_first_threshold',
		'value' => $__vars['reportQueue']['nf_discord_old_report_first_threshold'],
		'min' => '0',
	)) . '
					<span class="inputGroup-text">' . 'Hours' . '</span>
					</div></dd>
			</dl>

			<dl class="formRow formRow--input">
				<dt>' . 'Reminder of old reports after' . $__vars['xf']['language']['label_separator'] . '</dt>
				<dd><div class="inputGroup">
					' . $__templater->formNumberBox(array(
		'name' => 'nf_discord_old_report_repeat_threshold',
		'value' => $__vars['reportQueue']['nf_discord_old_report_repeat_threshold'],
		'min' => '0',
	)) . '
					<span class="inputGroup-text">' . 'minutes' . '</span>
					</div></dd>
			</dl>
		</div>
	</div>
');
	$__finalCompiled .= '
' . $__templater->callMacro('nf_discord_macros', 'channel', array(
		'node' => $__vars['reportQueue'],
		'channelList' => $__vars['discordChannels'],
		'extra' => $__vars['extra'],
	), $__vars);
	return $__finalCompiled;
}
);