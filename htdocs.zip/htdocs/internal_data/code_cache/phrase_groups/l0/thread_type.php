<?php
return array (
  'thread_type.article' => 'Article',
  'thread_type.discussion' => 'Discussion',
  'thread_type.poll' => 'Poll',
  'thread_type.question' => 'Question',
  'thread_type.redirect' => 'Redirect',
  'thread_type.suggestion' => 'Suggestion',
);