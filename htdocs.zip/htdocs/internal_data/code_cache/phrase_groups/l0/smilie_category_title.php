<?php
return array (
  'smilie_category_title.uncategorized' => 'Uncategorized smilies',
);