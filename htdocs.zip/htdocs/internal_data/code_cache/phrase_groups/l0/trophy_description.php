<?php
return array (
  'trophy_description.1' => 'Post a message somewhere on the site to receive this.',
  'trophy_description.2' => '30 messages posted. You must like it here!',
  'trophy_description.3' => 'You\'ve posted 100 messages. I hope this took you more than a day!',
  'trophy_description.4' => '1,000 messages? Impressive!',
  'trophy_description.5' => 'Somebody out there reacted positively to one of your messages. Keep posting like that for more!',
  'trophy_description.6' => 'Your messages have been positively reacted to 25 times.',
  'trophy_description.7' => 'Content you have posted has attracted a positive reaction score of 100.',
  'trophy_description.8' => 'Your content has been positively reacted to 250 times.',
  'trophy_description.9' => 'Content you have posted has attracted 500 positive reactions.',
);