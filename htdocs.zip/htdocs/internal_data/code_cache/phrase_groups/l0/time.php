<?php
return array (
  'time.day' => '{count} day',
  'time.days' => '{count} days',
  'time.hour' => '{count} hour',
  'time.hours' => '{count} hours',
  'time.minute' => '{count} minute',
  'time.minutes' => '{count} minutes',
  'time.month' => '{count} month',
  'time.months' => '{count} months',
  'time.second' => '{count} second',
  'time.seconds' => '{count} seconds',
  'time.weeks' => '{count} weeks',
  'time.year' => '{count} year',
  'time.years' => '{count} years',
);