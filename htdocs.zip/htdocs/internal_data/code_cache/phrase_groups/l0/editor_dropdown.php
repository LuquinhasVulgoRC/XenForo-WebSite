<?php
return array (
  'editor_dropdown.xfList' => 'List',
);