<?php
return array (
  'member_stat.highest_reaction_score' => 'Highest reaction score',
  'member_stat.most_messages' => 'Most messages',
  'member_stat.most_points' => 'Most points',
  'member_stat.most_solutions' => 'Most solutions',
  'member_stat.staff_members' => 'Staff members',
  'member_stat.todays_birthdays' => 'Today\'s birthdays',
);