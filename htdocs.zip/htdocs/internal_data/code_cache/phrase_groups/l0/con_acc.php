<?php
return array (
  'con_acc.discord' => 'Discord',
  'con_acc.facebook' => 'Facebook',
  'con_acc.github' => 'GitHub',
  'con_acc.google' => 'Google',
  'con_acc.linkedin' => 'Linkedin',
  'con_acc.microsoft' => 'Microsoft',
  'con_acc.nfDiscord' => 'Discord',
  'con_acc.nfDiscord_client_id' => 'Client ID',
  'con_acc.nfDiscord_client_id_explain' => 'The Client ID can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
  'con_acc.nfDiscord_client_secret' => 'Client secret',
  'con_acc.nfDiscord_client_secret_explain' => 'The Client Secret can be obtained after creating a new Web API Application via Discord\'s website <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.',
  'con_acc.nfDiscord_guild_id' => 'Guild ID',
  'con_acc.nfDiscord_guild_id_explain' => 'This is the Server ID of the Discord server that you will be integrating XenForo with. For more information on obtaining your Server ID, see <a href="https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-server-ID-" target="_blank">this guide</a>.',
  'con_acc.nfDiscord_token' => 'Bot token',
  'con_acc.nfDiscord_token_explain' => 'Your Discord application\'s bot token can be obtained after bundling a Bot User with your newly created Web API Application <a href="https://discord.com/developers/applications/me" target="_blank">here</a>.
<br /><br />
It is recommended that your bot is not public and also ensure that \'Require OAuth2 Code Grant\' is not checked.
<br /><br />
Once you have completed these steps, please invite your new Bot to your Discord server by visiting <a href="admin.php?discord/invite-bot" target="_blank">this page</a>.',
  'con_acc.twitter' => 'Twitter',
  'con_acc.yahoo' => 'Yahoo',
);