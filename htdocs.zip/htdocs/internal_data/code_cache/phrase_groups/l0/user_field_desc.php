<?php
return array (
  'user_field_desc.facebook' => '',
  'user_field_desc.skype' => '',
  'user_field_desc.twitter' => '',
);