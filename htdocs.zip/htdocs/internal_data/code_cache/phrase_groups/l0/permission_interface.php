<?php
return array (
  'permission_interface.bookmarkPermissions' => 'Bookmark permissions',
  'permission_interface.conversationModeratorPermissions' => 'Conversation moderator permissions',
  'permission_interface.conversationPermissions' => 'Conversation permissions',
  'permission_interface.discordPermissions' => 'Discord user permissions',
  'permission_interface.forumModeratorPermissions' => 'Forum moderator permissions',
  'permission_interface.forumPermissions' => 'Forum permissions',
  'permission_interface.generalModeratorPermissions' => 'General moderator permissions',
  'permission_interface.generalPermissions' => 'General permissions',
  'permission_interface.postAttachmentPermissions' => 'Post attachment permissions',
  'permission_interface.profilePostModeratorPermissions' => 'Profile post moderator permissions',
  'permission_interface.profilePostPermissions' => 'Profile post permissions',
  'permission_interface.signaturePermissions' => 'Signature permissions',
);