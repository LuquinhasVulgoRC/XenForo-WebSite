<?php
return array (
  'likes.1_person' => '1 person',
  'likes.deleted_user' => '(deleted member)',
  'likes.user1' => '{user1}',
  'likes.user1_and_user2' => '{user1} and {user2}',
  'likes.user1_user2_and_user3' => '{user1}, {user2} and {user3}',
  'likes.user1_user2_user3_and_1_other' => '{user1}, {user2}, {user3} and 1 other person',
  'likes.user1_user2_user3_and_x_others' => '{user1}, {user2}, {user3} and {others} others',
  'likes.x_people' => '{likes} people',
  'likes.you' => 'You',
  'likes.you_and_user1' => 'You and {user1}',
  'likes.you_user1_and_user2' => 'You, {user1} and {user2}',
  'likes.you_user1_user2_and_1_other' => 'You, {user1}, {user2} and 1 other person',
  'likes.you_user1_user2_and_x_others' => 'You, {user1}, {user2} and {others} others',
);