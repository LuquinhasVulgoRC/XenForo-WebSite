<?php
return array (
  'thread_type_plural.article' => 'Articles',
  'thread_type_plural.discussion' => 'Discussions',
  'thread_type_plural.poll' => 'Polls',
  'thread_type_plural.question' => 'Questions',
  'thread_type_plural.redirect' => 'Redirects',
  'thread_type_plural.suggestion' => 'Suggestions',
);