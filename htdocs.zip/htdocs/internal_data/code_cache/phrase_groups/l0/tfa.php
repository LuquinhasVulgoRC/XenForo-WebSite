<?php
return array (
  'tfa.authy' => 'Verification via Authy app',
  'tfa.backup' => 'Backup codes',
  'tfa.email' => 'Email confirmation',
  'tfa.totp' => 'Verification code via app',
);