<?php
return array (
  'nfDiscord_notice.report_move' => '{name} moved the report {contentTitle} by {contentName}',
  'nfDiscord_notice.report_new' => '{name} reported {contentTitle} by {contentName}',
  'nfDiscord_notice.report_old_open_reports' => '{queueName} has {openCount} open reports which are older than {time} hours',
  'nfDiscord_notice.report_reopened' => '{name} reported {contentTitle} by {contentName}',
  'nfDiscord_notice.report_too_many_open' => '{queueName} has more than {openThreshold} open reports; it has {openCount} open reports',
  'nfDiscord_notice.thread_approved' => '{name} had a thread called {title} approved',
  'nfDiscord_notice.thread_new' => '{name} started a thread called {title}.',
  'nfDiscord_notice.thread_reply' => '{name} replied to the thread {title}.',
  'nfDiscord_notice.user_association' => '{discordUser} associated their account with {username}.',
  'nfDiscord_notice.xfrm_resource_new' => '{username} created the resource {title} in {category}.',
);