<?php
return array (
  'thread_sort.post_date' => 'Sort by date',
  'thread_sort.vote_score' => 'Sort by votes',
);