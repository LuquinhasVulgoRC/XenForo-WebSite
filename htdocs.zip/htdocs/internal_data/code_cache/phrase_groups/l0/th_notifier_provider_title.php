<?php
return array (
  'th_notifier_provider_title.discord' => 'Discord',
  'th_notifier_provider_title.mattermost' => 'Mattermost',
  'th_notifier_provider_title.slack' => 'Slack',
);